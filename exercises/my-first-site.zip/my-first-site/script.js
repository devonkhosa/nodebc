window.onload = function() {
    var button = document.querySelector('button');
  
    button.addEventListener('click', function() {
      alert("Good job. You pass the test.");
    });
  }